__all__ = ["bird", "mammal","etc"]
