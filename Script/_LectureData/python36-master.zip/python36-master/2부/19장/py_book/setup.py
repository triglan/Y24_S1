from distutils.core import setup

setup(name='book',
    version='1.0',
    py_modules=['c:\\python30\\test'],
   ) 
