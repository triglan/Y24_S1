import turtle

turtle.circle(50)

turtle.done() 