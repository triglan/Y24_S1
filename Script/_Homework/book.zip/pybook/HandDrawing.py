import turtle

turtle.ondrag(turtle.goto)

turtle.done() 
