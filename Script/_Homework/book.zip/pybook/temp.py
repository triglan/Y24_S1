items = "09/20/2012".split("/")
print(items)

s = input("Enter a string: ")
print(s)

x1, x2, x3 = eval(input("Enter a number: "))
print(x1, x2, x3)