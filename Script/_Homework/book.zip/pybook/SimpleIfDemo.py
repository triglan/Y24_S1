number = eval(input("Enter an integer: "))

if number % 5 == 0 :
   print("HiFive");

if number % 2 == 0 :
   print("HiEven");