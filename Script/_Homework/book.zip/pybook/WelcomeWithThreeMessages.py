# Display three messages
print("Welcome to Python")
print("Python is fun")
print("Problem Driven")  
